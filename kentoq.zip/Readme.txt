file-name       contents
----------      -------------------------------------

Readme.txt      this information

kentoqnr.mac    SAS macro KENTOQNR

kentoqgs.mac    SAS macro KENTOQGS

lungdata.sas    Veteran's administration lung cancer 
                data as published in Kalbfleisch and 
                Prentice (1980) 

lungcox.sas     Sample calls of the SAS macros for 
                the lung cancer data set